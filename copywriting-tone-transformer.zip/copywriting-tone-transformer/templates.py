"""
templates.py — Master Instruction Template Compiler
DecodeLabs — Generative AI Project 2

Step 3 of Deployment Checklist:
  Build the Master Template using f-strings to lock in brand safety
  guidelines and platform-specific constraints.

Key principle: The application layer is the gatekeeper.
  Raw user inputs → sanitized → injected into the hidden template.
  The end-user provides raw facts; the code enforces the structural prompt.
"""

# ─────────────────────────────────────────────
#  PLATFORM CONFIGURATION PROFILES
#  Platform-specific filtering: conditional logic appends strict
#  constraints (e.g., Twitter/X: Maximum 280 characters) directly
#  into the payload before API transmission.
# ─────────────────────────────────────────────

PLATFORM_PROFILES = {
    "linkedin": {
        "label": "LinkedIn",
        "char_limit": 3000,
        "constraint": "Write in a professional, thought-leadership style. Keep under 300 words. Use line breaks for readability. No excessive hashtags (max 3).",
        "include_hashtags": True,
        "max_hashtags": 3,
    },
    "instagram": {
        "label": "Instagram",
        "char_limit": 2200,
        "constraint": "Write in an engaging, visual storytelling style. Keep under 150 words. Use emojis sparingly. Include 5-10 relevant hashtags.",
        "include_hashtags": True,
        "max_hashtags": 10,
    },
    "twitter": {
        "label": "Twitter/X",
        "char_limit": 280,
        "constraint": "CRITICAL: Body text must be UNDER 280 characters total. Be punchy, direct, and impactful. Max 2 hashtags.",
        "include_hashtags": True,
        "max_hashtags": 2,
    },
    "email": {
        "label": "Email",
        "char_limit": 5000,
        "constraint": "Write a professional marketing email. Include a compelling subject line, personalized opening, value proposition, and clear CTA. Keep body under 200 words.",
        "include_hashtags": False,
        "max_hashtags": 0,
    },
    "facebook": {
        "label": "Facebook",
        "char_limit": 63206,
        "constraint": "Write in a friendly, community-oriented tone. Keep under 200 words. Ask an engaging question to boost comments. Max 3 hashtags.",
        "include_hashtags": True,
        "max_hashtags": 3,
    },
}

# ─────────────────────────────────────────────
#  TONE CONFIGURATION
#  Temperature mapping: tone → temperature value
#  High temp (0.8) = diverse, witty social copy
#  Low temp (0.2)  = consistent, factual professional emails
# ─────────────────────────────────────────────

TONE_PROFILES = {
    "professional":   {"temperature": 0.2, "top_p": 0.85, "description": "Formal, credible, authoritative"},
    "witty":          {"temperature": 0.8, "top_p": 0.95, "description": "Playful, clever, unexpected hooks"},
    "urgent":         {"temperature": 0.5, "top_p": 0.90, "description": "Time-sensitive, action-driving"},
    "inspirational":  {"temperature": 0.7, "top_p": 0.92, "description": "Motivating, aspirational, emotionally resonant"},
    "friendly":       {"temperature": 0.6, "top_p": 0.90, "description": "Warm, approachable, conversational"},
    "minimalist":     {"temperature": 0.3, "top_p": 0.85, "description": "Clean, concise, no fluff"},
    "luxury":         {"temperature": 0.4, "top_p": 0.88, "description": "Sophisticated, exclusive, premium feel"},
}


# ─────────────────────────────────────────────
#  MASTER INSTRUCTION TEMPLATE COMPILER
#  f-strings inject user variables securely into the hidden template.
# ─────────────────────────────────────────────

def compile_prompt(
    product_name: str,
    product_description: str,
    platform: str,
    tone: str,
    target_audience: str = "general consumers",
    unique_selling_point: str = "",
) -> str:
    """
    Compile the Master Instruction Template.

    Dynamic variables injected via f-strings:
      {product_name}        — the product being marketed
      {product_description} — raw facts provided by user
      {platform_label}      — formatted platform name
      {platform_constraint} — strict platform rules (char limits, style)
      {tone}                — desired tone of voice
      {tone_description}    — what that tone means in practice
      {target_audience}     — who the copy is aimed at
      {usp}                 — unique selling point (optional)

    Returns the fully compiled prompt string ready for API transmission.
    """
    platform_key = platform.lower()
    tone_key = tone.lower()

    # Sanitize inputs — application layer as gatekeeper
    if platform_key not in PLATFORM_PROFILES:
        raise ValueError(f"Unsupported platform '{platform}'. Choose: {list(PLATFORM_PROFILES.keys())}")
    if tone_key not in TONE_PROFILES:
        raise ValueError(f"Unsupported tone '{tone}'. Choose: {list(TONE_PROFILES.keys())}")

    profile  = PLATFORM_PROFILES[platform_key]
    tone_cfg = TONE_PROFILES[tone_key]

    usp_line = f"\nUnique Selling Point: {unique_selling_point}" if unique_selling_point else ""

    # ── The Master Instruction Template ──
    compiled = f"""You are an expert marketing copywriter. Generate high-converting marketing copy with absolute precision.

PRODUCT BRIEF:
  Product Name: {product_name}
  Description: {product_description}
  Target Audience: {target_audience}{usp_line}

PLATFORM TARGET: {profile['label']}
PLATFORM CONSTRAINTS: {profile['constraint']}

TONE OF VOICE: {tone.upper()} — {tone_cfg['description']}

OUTPUT FORMAT (respond ONLY with valid JSON, no markdown):
{{
  "platform": "{profile['label']}",
  "tone": "{tone}",
  "headline": "<compelling headline or email subject line>",
  "body": "<main copy body — must respect platform constraints>",
  "cta": "<clear call-to-action>",
  "character_count": <integer count of body characters>,
  "hashtags": {"<space-separated hashtags>" if profile['include_hashtags'] else "null"}
}}

CRITICAL RULES:
1. Body text must respect the platform character limit ({profile['char_limit']} chars max).
2. Tone must be consistently {tone} throughout — do not drift.
3. Return ONLY the JSON object. No preamble, no explanation, no markdown fences.
4. The headline should make someone stop scrolling immediately.
5. The CTA must be specific and action-oriented (not generic like "click here")."""

    return compiled


def get_inference_params(tone: str, platform: str) -> dict:
    """
    Return the inference hyperparameters for a given tone + platform combination.

    Token Limit Decision Tree (from blueprint):
      - Standard models (gpt-4o): use max_tokens
      - Legacy models (gpt-4, gpt-3.5-turbo): use max_tokens (50–500 range)
      - Modern reasoning models (o1): use max_completion_tokens (150–300)

    Temperature spectrum:
      0.8 (High) → diverse phrasing, unexpected linguistic hooks → social media
      0.2 (Low)  → consistent, structured, factual → professional emails
    """
    tone_key     = tone.lower()
    platform_key = platform.lower()

    tone_cfg     = TONE_PROFILES.get(tone_key, TONE_PROFILES["professional"])
    plat_profile = PLATFORM_PROFILES.get(platform_key, PLATFORM_PROFILES["linkedin"])

    # Adjust token budget by platform
    token_map = {
        "twitter":   150,   # Short — 280 char limit
        "instagram": 300,
        "linkedin":  400,
        "facebook":  400,
        "email":     500,
    }
    max_tokens = token_map.get(platform_key, 400)

    return {
        "temperature": tone_cfg["temperature"],
        "top_p":       tone_cfg["top_p"],
        "max_tokens":  max_tokens,
    }
