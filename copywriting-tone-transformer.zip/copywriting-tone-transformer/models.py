"""
models.py — Pydantic Output Schemas
DecodeLabs — Generative AI Project 2

Step 1 of Deployment Checklist:
  Define strict output schemas for final copy generation.
  Pydantic validates that every API response is structurally correct
  before it is delivered to the pipeline — no malformed JSON escapes.
"""

from pydantic import BaseModel, Field
from typing import Optional


class CopyOutput(BaseModel):
    """Structured output for a single piece of generated marketing copy."""

    platform: str = Field(description="Target platform (LinkedIn, Instagram, Email, Twitter, etc.)")
    tone: str = Field(description="Tone used (professional, witty, urgent, inspirational, etc.)")
    headline: str = Field(description="Attention-grabbing headline or subject line")
    body: str = Field(description="Main copy body — platform-length compliant")
    cta: str = Field(description="Call-to-action text")
    character_count: Optional[int] = Field(default=None, description="Total character count of body")
    hashtags: Optional[str] = Field(default=None, description="Relevant hashtags (social platforms only)")


class BatchCopyOutput(BaseModel):
    """Container for a batch of copy variations across multiple platforms/tones."""
    product_name: str
    description: str
    variations: list[CopyOutput]
